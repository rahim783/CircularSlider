package com.example.circulerslider

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity()
